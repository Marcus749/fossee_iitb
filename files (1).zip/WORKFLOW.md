# Workflow checklist
1. Fork FOSSEE/eSim, clone, `git checkout installer`
2. Copy `esim-diagnose.sh` into repo root, report into `docs/`
3. VM snapshot -> `bash esim-diagnose.sh env > docs/env.md`
4. `bash esim-diagnose.sh audit install-eSim.sh > docs/audit.md`
5. `mkdir logs; script -q -c "bash -x ./install-eSim.sh --install" logs/run1.log`
6. `bash esim-diagnose.sh scan logs/run1.log` -> pick the failure that blocks the GUI first
7. Fix one issue, commit (`installer: fix <thing> on Ubuntu 25.04`), revert snapshot, re-run
8. Repeat; fill the report from real logs only
9. `git push origin installer`; email contact-esim@fossee.in
   Subject: eSim Semester Long Internship - Autumn 2026 Submission Task 4
