# eSim 2.5 on Ubuntu 25.04: Installation Issues and Fixes

> Rule for this document: every issue below must come from a real log line.
> Delete any section you could not reproduce. Do not leave template text in.

## 1. Environment
Paste output of `bash esim-diagnose.sh env` here.

| Item | Value |
|---|---|
| Host / VM | e.g. VirtualBox 7.x, 4 CPU, 8 GB RAM, 40 GB disk |
| Ubuntu | 25.04 (fresh install, snapshot taken before run) |
| eSim source | FOSSEE/eSim, branch `installer`, commit `<hash>` |
| Command run | `bash -x ./install-eSim.sh --install` |
| Raw log | `logs/run1.log` |

## 2. Summary

| # | Component | Symptom (short) | Blocks main GUI? | Status |
|---|---|---|---|---|
| 1 | | | Yes / No | Fixed / Worked around / Open |
| 2 | | | | |

## 3. Methodology
1. Fresh snapshot, ran installer with `bash -x` and `script` logging.
2. Ran `esim-diagnose.sh audit install-eSim.sh` before running, to catch missing packages and PPAs statically.
3. Ran `esim-diagnose.sh scan <log>` after each failed run.
4. Fixed one issue at a time. After each fix, reverted to the snapshot and re-ran the full install, so a fix is only counted if it works from a clean state.

## 4. Issues

### Issue N: <title>
- **Component:** (e.g. Python deps / KiCad / Ngspice / LLVM / NGHDL / NgVeri)
- **Severity:** blocks GUI / blocks optional module
- **Location:** `install-eSim.sh:<line>`
- **Command:** `<exact command>`
- **Error (verbatim):**
```
<paste exact error>
```
- **Root cause:** what is actually wrong, with evidence (e.g. `apt-cache policy` output, Python version, PEP 668 marker file).
- **Fix:** commit `<hash>` / link. Diff:
```diff
- old line
+ new line
```
- **Verification:** exact command and output proving it works from a clean snapshot (e.g. `esim` launches, `ngspice --version`).
- **Why this approach:** alternatives considered and rejected.

## 5. Unresolved issues
For each: what you tried, what you observed, what you would try next. Lines commented out in the script must be marked `# TEMP-DISABLED (issue #N)`.

## 6. Reproduction
```bash
git clone -b installer https://github.com/<you>/eSim.git
cd eSim && bash esim-diagnose.sh audit install-eSim.sh
script -q -c "bash -x ./install-eSim.sh --install" logs/run.log
bash esim-diagnose.sh scan logs/run.log
```

## 7. Final result
State plainly: does the eSim GUI launch after the install? What still fails?
