#!/usr/bin/env bash
# Old-vs-fixed comparison on a MOCKED Ubuntu environment. Run: bash tests/run_tests.sh
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MOCKS=$(mktemp -d); cp "$HERE"/mocks/bin/* "$MOCKS"/; chmod +x "$MOCKS"/*   # copy: repo mounts may be noexec
PASS=0; FAIL=0
GREEN=$'\e[32m'; RED=$'\e[31m'; RST=$'\e[0m'

# run <scenario-env-assignments> <bash snippet>  -> sets RC, OUT, STATE
run() {
  STATE=$(mktemp -d); TMP=$(mktemp -d)
  OUT=$(env MOCK_STATE="$STATE" TMP="$TMP" KICAD_CONFIG_BASE="$TMP/kicadcfg" \
        PATH="$MOCKS:$PATH" $1 bash -c "
          set -e
          source '$HERE/legacy/original_logic.sh'
          source '$HERE/lib/esim_fixes.sh'
          $2" 2>&1); RC=$?
}
check() { # check <desc> <condition-exit-code>
  if [ "$2" -eq 0 ]; then echo "  ${GREEN}PASS${RST} $1"; PASS=$((PASS+1))
  else echo "  ${RED}FAIL${RST} $1"; echo "       output: ${OUT:0:300}"; FAIL=$((FAIL+1)); fi
}
section() { echo; echo "== $1"; }

# ---------------------------------------------------------------- C1
section "C1  PPA detection (one-line .list and deb822 .sources)"
mkdir -p /tmp/esimsrc/list /tmp/esimsrc/deb822 /tmp/esimsrc/empty
echo "deb https://ppa.launchpadcontent.net/kicad/kicad-8.0-releases/ubuntu plucky main" > /tmp/esimsrc/list/kicad.list
printf 'Types: deb\nURIs: https://ppa.launchpadcontent.net/kicad/kicad-8.0-releases/ubuntu\nSuites: plucky\n' > /tmp/esimsrc/deb822/kicad.sources
touch /tmp/esimsrc/empty/none.list

run "LEGACY_SOURCES=/tmp/esimsrc/list/*" 'legacy_ppa_present kicad/kicad-8.0-releases && echo FOUND || echo MISSING'
echo "$OUT" | grep -q MISSING; check "legacy: PPA present but reported MISSING (bug reproduced)" $?
run "ESIM_SOURCES_PATHS=/tmp/esimsrc/list" 'esim_ppa_present kicad/kicad-8.0-releases && echo FOUND || echo MISSING'
echo "$OUT" | grep -q FOUND; check "fixed: detects PPA in .list" $?
run "ESIM_SOURCES_PATHS=/tmp/esimsrc/deb822" 'esim_ppa_present kicad/kicad-8.0-releases && echo FOUND || echo MISSING'
echo "$OUT" | grep -q FOUND; check "fixed: detects PPA in deb822 .sources" $?
run "ESIM_SOURCES_PATHS=/tmp/esimsrc/empty" 'esim_ppa_present kicad/kicad-8.0-releases && echo FOUND || echo MISSING'
echo "$OUT" | grep -q MISSING; check "fixed: correctly reports absent PPA" $?

# ---------------------------------------------------------------- C2
section "C2  KiCad install when the PPA has no Release for this Ubuntu"
run "MOCK_PPA_DEAD=1 ESIM_SOURCES_PATHS=/tmp/esimsrc/empty LEGACY_SOURCES=/tmp/esimsrc/empty/*" 'legacy_install_kicad'
[ $RC -ne 0 ] && [ $RC -ne 126 ] && echo "$OUT" | grep -q "does not have a Release file"; check "legacy: aborts on 'does not have a Release file' (rc=$RC)" $?
run "MOCK_PPA_DEAD=1 ESIM_SOURCES_PATHS=/tmp/esimsrc/empty" 'esim_install_kicad; echo "SRC=$ESIM_KICAD_SOURCE"; test ! -f "$MOCK_STATE/ppa_added"'
[ $RC -eq 0 ] && echo "$OUT" | grep -q "SRC=archive"; check "fixed: removes dead PPA, installs kicad from archive" $?
run "MOCK_PPA_DEAD=0 ESIM_SOURCES_PATHS=/tmp/esimsrc/empty" 'esim_install_kicad; echo "SRC=$ESIM_KICAD_SOURCE"'
[ $RC -eq 0 ] && echo "$OUT" | grep -q "SRC=ppa"; check "fixed: healthy PPA is used as 'ppa'" $?
run "MOCK_PPA_DEAD=1 MOCK_MISSING=kicad ESIM_SOURCES_PATHS=/tmp/esimsrc/empty" 'esim_install_kicad; echo "SRC=$ESIM_KICAD_SOURCE"'
[ $RC -eq 0 ] && echo "$OUT" | grep -q "SRC=snap" && grep -q "snap install kicad" "$STATE/calls.log"; check "fixed: no apt candidate -> falls back to snap" $?

# ---------------------------------------------------------------- C3
section "C3  KiCad config directory / version"
run "MOCK_KICAD_VERSION=1:9.0.1-1" 'echo kicad >> "$MOCK_STATE/installed"; legacy_kicad_config'
echo "$OUT" | grep -q "/8.0$"; check "legacy: KiCad 9 installed but config dir is 8.0 (bug reproduced)" $?
run "MOCK_KICAD_VERSION=1:9.0.1-1" 'echo kicad >> "$MOCK_STATE/installed"; d=$(esim_kicad_config_dir); echo "$d"; test -d "$d"'
[ $RC -eq 0 ] && echo "$OUT" | grep -q "/9.0$"; check "fixed: detects 9.0 from dpkg version (epoch stripped), dir created" $?
run "" 'esim_kicad_config_dir'
[ $RC -eq 0 ] && echo "$OUT" | grep -q "WARNING"; check "fixed: unknown version -> warns instead of silently guessing" $?
run "" 'legacy_kicad_config'
[ $RC -eq 0 ]; check "REFUTED hypothesis: legacy 'ls' on missing dir does NOT abort (pipeline status is tail's)" $?

# ---------------------------------------------------------------- C4
section "C4  python3-distutils absent from the archive"
run "MOCK_MISSING=python3-distutils" 'legacy_install_distutils; echo REACHED_NEXT_STEP'
[ $RC -ne 0 ] && [ $RC -ne 126 ] && echo "$OUT" | grep -q "Unable to locate package python3-distutils" && ! echo "$OUT" | grep -q REACHED_NEXT_STEP; check "legacy: aborts the whole installer (rc=$RC)" $?
run "MOCK_MISSING=python3-distutils" 'mkdir -p "$TMP/venv/bin"; printf "#!/bin/bash\necho pip \$* >> \"$MOCK_STATE/calls.log\"\n" > "$TMP/venv/bin/pip"; chmod +x "$TMP/venv/bin/pip"; esim_install_distutils_compat "$TMP/venv"; echo REACHED_NEXT_STEP'
[ $RC -eq 0 ] && grep -q "pip install --upgrade setuptools" "$STATE/calls.log"; check "fixed: continues and installs setuptools into the venv" $?
run "" 'mkdir -p "$TMP/venv/bin"; esim_install_distutils_compat "$TMP/venv"'
[ $RC -eq 0 ] && grep -qx python3-distutils "$STATE/installed"; check "fixed: uses apt package when it does exist" $?

# ---------------------------------------------------------------- C5
section "C5  Fail loudly with no half-installs"
run "MOCK_MISSING=libfoo" 'esim_apt_install xterm libfoo python3-pip'
[ $RC -ne 0 ] && echo "$OUT" | grep -q "libfoo" && [ ! -s "$STATE/installed" ]; check "fixed: names the missing package and installs nothing" $?
run "" 'esim_apt_install xterm python3-pip'
[ $RC -eq 0 ] && grep -qx xterm "$STATE/installed"; check "fixed: installs normally when all packages exist" $?

echo; echo "RESULT: $PASS passed, $FAIL failed"
[ "$FAIL" -eq 0 ]
