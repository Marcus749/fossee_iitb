#!/usr/bin/env bash
# Fixed helper functions for the eSim installer on Ubuntu 25.04. SOURCE this file.
# Paths are overridable via env vars so everything can be tested without root.

ESIM_SOURCES_PATHS="${ESIM_SOURCES_PATHS:-/etc/apt/sources.list /etc/apt/sources.list.d}"
esim_log() { echo "[eSim-fix] $*"; }

# C1: detect a PPA in one-line (.list "deb ...") and deb822 (.sources "URIs: ...") formats.
esim_ppa_present() {
  local ppa="$1" p
  for p in $ESIM_SOURCES_PATHS; do
    [ -e "$p" ] || continue
    grep -rhsF "$ppa" "$p" | grep -qE '^(deb[[:space:]]|URIs:)' && return 0
  done
  return 1
}

# True if apt has an installable candidate for the package in THIS release.
esim_pkg_available() {
  local c
  c=$(apt-cache policy "$1" 2>/dev/null | awk '/Candidate:/{print $2}')
  [ -n "$c" ] && [ "$c" != "(none)" ]
}

# Fail loudly, naming missing packages, BEFORE installing anything (no half-installs).
esim_apt_install() {
  local pkg missing=()
  for pkg in "$@"; do esim_pkg_available "$pkg" || missing+=("$pkg"); done
  if [ "${#missing[@]}" -gt 0 ]; then
    echo "ERROR: not available in this Ubuntu release's archive: ${missing[*]}" >&2
    return 1
  fi
  sudo apt-get install -y "$@"
}

# C2: KiCad via PPA -> rollback on broken PPA -> archive -> snap. Sets ESIM_KICAD_SOURCE.
esim_install_kicad() {
  local ppa="${1:-kicad/kicad-8.0-releases}" ppa_added=0
  ESIM_KICAD_SOURCE=""
  if ! esim_ppa_present "$ppa"; then
    esim_log "Adding PPA ppa:$ppa"
    if sudo add-apt-repository -y "ppa:$ppa"; then ppa_added=1; fi
  fi
  if ! sudo apt-get update; then
    esim_log "apt update failed with PPA present; removing PPA and falling back"
    if [ "$ppa_added" -eq 1 ]; then sudo add-apt-repository -r -y "ppa:$ppa"; fi
    sudo apt-get update || { echo "ERROR: apt update still failing after PPA rollback" >&2; return 1; }
    ppa_added=0
  fi
  if esim_pkg_available kicad; then
    sudo apt-get install -y --no-install-recommends kicad || return 1
    if [ "$ppa_added" -eq 1 ]; then ESIM_KICAD_SOURCE="ppa"; else ESIM_KICAD_SOURCE="archive"; fi
    return 0
  fi
  if command -v snap >/dev/null 2>&1; then
    esim_log "No apt candidate for kicad; installing via snap"
    if sudo snap install kicad; then ESIM_KICAD_SOURCE="snap"; return 0; fi
  fi
  echo "ERROR: could not install KiCad from PPA, archive or snap" >&2
  return 1
}

# C3: detect installed KiCad major.minor instead of hardcoding "8.0".
esim_kicad_version() {
  local v=""
  v=$(dpkg-query -W -f='${Version}' kicad 2>/dev/null) || v=""
  if [ -z "$v" ]; then v=$(kicad-cli --version 2>/dev/null | head -1) || v=""; fi
  v=$(echo "$v" | sed -E 's/^[0-9]+://' | grep -oE '^[0-9]+\.[0-9]+') || v=""
  if [ -n "$v" ]; then echo "$v"; return 0; fi
  return 1
}

# Prints the version-specific KiCad config dir (created). Warns if it has to guess.
esim_kicad_config_dir() {
  local base="${KICAD_CONFIG_BASE:-$HOME/.config/kicad}" ver=""
  mkdir -p "$base"
  ver=$(esim_kicad_version) || ver=""
  if [ -z "$ver" ]; then
    ver=$(ls "$base" 2>/dev/null | grep -E '^[0-9]+\.[0-9]+$' | sort -V | tail -n 1) || true
  fi
  if [ -z "$ver" ]; then ver="8.0"; esim_log "WARNING: KiCad version unknown, defaulting to $ver" >&2; fi
  mkdir -p "$base/$ver"
  echo "$base/$ver"
}

# C4: python3-distutils may not exist (distutils removed from Python 3.12+).
esim_install_distutils_compat() {
  local venv="$1"
  if esim_pkg_available python3-distutils; then
    sudo apt-get install -y python3-distutils
  else
    esim_log "python3-distutils unavailable; installing setuptools into venv instead"
    "$venv/bin/pip" install --upgrade setuptools
  fi
}
