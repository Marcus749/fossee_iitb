# Working model: old installer logic vs fixed logic, on a mocked Ubuntu

Run: `bash tests/run_tests.sh` (needs only bash; no root, no network, touches nothing outside /tmp).

## What this IS
- `legacy/original_logic.sh`: upstream logic as read from FOSSEE/eSim `installers`, kept for comparison.
- `lib/esim_fixes.sh`: fixed functions you can source into the 25.04 installer.
- `mocks/bin/`: fake `apt-get`, `apt-cache`, `add-apt-repository`, `dpkg-query`, `snap`, `sudo`.
  Scenario switches: `MOCK_PPA_DEAD=1`, `MOCK_MISSING="pkg1 pkg2"`, `MOCK_KICAD_VERSION=...`.
- `tests/run_tests.sh`: 17 checks. Legacy tests must fail for the *right* reason (real apt exit code
  and error text), so a broken harness cannot produce a false pass.

## What this is NOT
It is not proof that the fixes work on a real Ubuntu 25.04. Mocks encode MY ASSUMPTIONS about apt
behaviour (e.g. that the KiCad 8 PPA lacks a `plucky` Release, that `python3-distutils` is absent).
Those assumptions are the [HYPOTHESIS] items; the VM run decides which are real.

## Using it in your submission
1. On the VM, confirm each scenario against your real log (`bash ../esim-diagnose.sh scan`).
2. Only for confirmed issues: source `lib/esim_fixes.sh` in `install-eSim-25.04.sh` and replace the
   matching upstream lines with the fixed function.
3. Re-run the full install from a clean snapshot. That result, not this test suite, is your evidence.
4. Keep this suite in the repo as regression tests; cite it as "mock-based unit tests", never as
   "tested on Ubuntu 25.04".
