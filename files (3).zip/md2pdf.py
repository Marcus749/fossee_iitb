#!/usr/bin/env python3
"""Convert the eSim report markdown to PDF (reportlab only, no pandoc needed).
Usage: python3 tools/md2pdf.py docs/INSTALL_UBUNTU_25.04_REPORT.md report.pdf [--draft]
Supports: # headings, > quotes, bullets, numbered lists, ``` code, | tables |, **bold**, `code`.
--draft adds a DRAFT footer and warns on leftover <placeholders>."""
import re, sys, textwrap
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                Preformatted, PageBreak, KeepTogether)

AUTHOR = {"name": "Gyan Prakash Patel", "email": "gyan100485@gmail.com", "date": "22 November 2026"}
src, out = sys.argv[1], sys.argv[2]
draft = "--draft" in sys.argv

ss = getSampleStyleSheet()
N = ParagraphStyle("N", parent=ss["Normal"], fontName="Helvetica", fontSize=10, leading=14, spaceAfter=4)
H1 = ParagraphStyle("H1", parent=N, fontName="Helvetica-Bold", fontSize=20, leading=24, spaceAfter=8, textColor=colors.HexColor("#1F3864"))
H2 = ParagraphStyle("H2", parent=N, fontName="Helvetica-Bold", fontSize=14, leading=18, spaceBefore=12, spaceAfter=6, textColor=colors.HexColor("#1F3864"))
H3 = ParagraphStyle("H3", parent=N, fontName="Helvetica-Bold", fontSize=11.5, leading=15, spaceBefore=8, spaceAfter=4)
Q = ParagraphStyle("Q", parent=N, leftIndent=10, textColor=colors.HexColor("#555555"), fontName="Helvetica-Oblique")
B = ParagraphStyle("B", parent=N, leftIndent=14, bulletIndent=4)
TC = ParagraphStyle("TC", parent=N, fontSize=8.5, leading=11, spaceAfter=0)
TH = ParagraphStyle("TH", parent=TC, fontName="Helvetica-Bold", textColor=colors.white)
CODE = ParagraphStyle("CODE", fontName="Courier", fontSize=8, leading=10, backColor=colors.HexColor("#F2F2F2"),
                      borderPadding=4, leftIndent=4, spaceBefore=4, spaceAfter=8)

REPL = {"\u2192": "->", "\u2014": "-", "\u2013": "-", "\u2018": "'", "\u2019": "'", "\u201c": '"', "\u201d": '"',
        "\u2705": "[Fixed]", "\U0001F7E1": "[Workaround]", "\u274c": "[Open]", "\u00b7": "-"}
def clean(t):
    for k, v in REPL.items(): t = t.replace(k, v)
    return t.encode("latin-1", "replace").decode("latin-1")

def inline(t):
    t = clean(t).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"`([^`]+)`", r'<font face="Courier" size="9">\1</font>', t)
    t = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", r'<font color="#0563C1">\1</font>', t)
    return t

lines = open(src, encoding="utf-8").read().split("\n")
story = []
# front matter
story += [Paragraph("eSim 2.5 on Ubuntu 25.04", H1),
          Paragraph("Installation Issues and Fixes: Task 4 Report", H3),
          Paragraph(f"<b>Author:</b> {AUTHOR['name']} &nbsp;|&nbsp; <b>Email:</b> {AUTHOR['email']} &nbsp;|&nbsp; <b>Date:</b> {AUTHOR['date']}", N),
          Paragraph("<b>Programme:</b> FOSSEE Semester Long Internship, Autumn 2026 (Task 4, eSim Upgradation)", N),
          Paragraph("<b>Repository:</b> https://github.com/Marcus749/fossee_iitb", N), Spacer(1, 6)]

i, leftover = 0, []
first_h1_skipped = False
while i < len(lines):
    ln = lines[i]
    if ln.startswith("```"):
        buf = []; i += 1
        while i < len(lines) and not lines[i].startswith("```"):
            buf += textwrap.wrap(clean(lines[i]), 100, break_long_words=True, replace_whitespace=False) or [""]; i += 1
        story.append(Preformatted("\n".join(buf), CODE)); i += 1; continue
    if ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells): rows.append(cells)
            i += 1
        n = max(len(r) for r in rows)
        data = [[Paragraph(inline(c), TH if ri == 0 else TC) for c in r + [""] * (n - len(r))] for ri, r in enumerate(rows)]
        t = Table(data, colWidths=[(A4[0] - 40 * mm) / n] * n, repeatRows=1)
        t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3864")),
                               ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BFBFBF")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"),
                               ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F7F7")])]))
        story += [t, Spacer(1, 8)]; continue
    if ln.startswith("# "):
        if not first_h1_skipped: first_h1_skipped = True   # title already in front matter
        else: story.append(Paragraph(inline(ln[2:]), H2))
    elif ln.startswith("## "): story.append(Paragraph(inline(ln[3:]), H2))
    elif ln.startswith("### "): story.append(Paragraph(inline(ln[4:]), H3))
    elif ln.startswith("> "): story.append(Paragraph(inline(ln[2:]), Q))
    elif re.match(r"^\s*- ", ln): story.append(Paragraph(inline(re.sub(r"^\s*- ", "", ln)), B, bulletText="\u2022"))
    elif re.match(r"^\d+\. ", ln):
        m = re.match(r"^(\d+)\. (.*)", ln); story.append(Paragraph(inline(m.group(2)), B, bulletText=m.group(1) + "."))
    elif ln.strip() == "---": story.append(Spacer(1, 4))
    elif ln.strip(): story.append(Paragraph(inline(ln), N))
    if re.search(r"<[A-Za-z][^>]*>", ln) and not ln.startswith("```"): leftover.append(ln.strip()[:70])
    i += 1

def footer(c, d):
    c.saveState(); c.setFont("Helvetica", 8); c.setFillColor(colors.HexColor("#777777"))
    c.drawString(20 * mm, 10 * mm, "eSim Task 4 - Gyan Prakash Patel" + ("  |  DRAFT: placeholders not yet filled" if draft else ""))
    c.drawRightString(A4[0] - 20 * mm, 10 * mm, f"Page {d.page}"); c.restoreState()

SimpleDocTemplate(out, pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm, topMargin=18 * mm, bottomMargin=18 * mm,
                  title="eSim 2.5 on Ubuntu 25.04: Installation Issues and Fixes", author=AUTHOR["name"]).build(story, onFirstPage=footer, onLaterPages=footer)
print(f"wrote {out}")
if leftover: print(f"WARNING: {len(leftover)} line(s) still contain <placeholders>, e.g.: {leftover[:3]}")
